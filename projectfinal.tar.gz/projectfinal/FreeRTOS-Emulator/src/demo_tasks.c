#include "TUM_Draw.h"
#include "TUM_Event.h"
#include "TUM_Ball.h"
#include "TUM_Sound.h"
#include "TUM_Utils.h"
#include "TUM_Print.h"

#include "defines.h"
#include "main.h"
#include "demo_tasks.h"
#include "async_message_queues.h"
#include "async_sockets.h"
#include "buttons.h"
#include "state_machine.h"
#include "draw.h"
#include "states.h"

#define GAME_MENU 0
#define NORMAL_GAME 1
#define REPLAY 2
#define MULTIPLAYER_GAME 3
#define BirdSpace 368
#define GRAVITY 0.28;

TaskHandle_t DemoTask1 = NULL;
TaskHandle_t DemoTask2 = NULL;
TaskHandle_t DemoTask3 = NULL;
TaskHandle_t DemoTask4 = NULL;
TaskHandle_t DemoSendTask = NULL;
struct game_data {
    int count_down;
    int score;
    int gameover;
} game;


struct locked_ball {
    ball_t *ball;
    SemaphoreHandle_t lock;
} my_ball = { 0 };

void vStateOneEnter(void)
{
    vTaskResume(DemoTask1);
}

void vStateOneExit(void)
{
    vTaskSuspend(DemoTask1);
}
//Menu TASK
void vDemoTask1(void *pvParameters)
{
    
    TickType_t xLastFrameTime = xTaskGetTickCount();
    TickType_t frame=xLastFrameTime;

    int x = 0;
    float angle;
    

    int x1;
    int y1;

    int x_min=105;
    int x_max=280;
    int y_min=284;
    int y_max=373;
    //int pause = 0;
    while (1) {
        if (DrawSignal)
            if (xSemaphoreTake(DrawSignal, portMAX_DELAY) ==
                pdTRUE) {
                tumEventFetchEvents(FETCH_EVENT_BLOCK |
                                    FETCH_EVENT_NO_GL_CHECK);
                vGetButtonInput(); // Update global input

                vDrawClearScreen();
                vDrawStaticItems();
                
                x1=tumEventGetMouseX();
                y1=tumEventGetMouseY();

                //vDrawMouseBallAndBoundingBox(tumEventGetMouseLeft());
                //vDrawButtonText();
                
                    
                xLastFrameTime = xTaskGetTickCount();
                 angle=(xLastFrameTime-frame)/(500.0);//oscillation
                
                x= 30+10*sin(5*angle);
                if (angle>=2*3.14) angle = 0;

                    if (xSemaphoreTake(buttons.lock, 0) == pdTRUE) {
                        if (tumEventGetMouseLeft()) {
                            if (x1 > x_min && x1 < x_max && y1 > y_min && y1 < y_max)                           
                                uStatesSetState(STATE_TWO);
                                
                        }    
                        xSemaphoreGive(buttons.lock);
                    }
                vDrawMenu(x);     
                
            }
                
    }
}
void vStateThreeEnter(void)
{
	vTaskResume(DemoTask3);
}

void vStateThreeExit(void)
{
	vTaskSuspend(DemoTask3);
}
//Game over task
void vDemoTask3(void *pvParameters)
{
    int x_min=280;
    int x_max=370;
    int y_min=270;
    int y_max=350; 
    int  x1;
    int  y1;
    
    while (1) {
        if (DrawSignal)
            if (xSemaphoreTake(DrawSignal, portMAX_DELAY) ==
                pdTRUE) {

                if ( game.gameover == 1) {
                    vDrawClearScreen();
                    vDrawStaticItems();
                    x1=tumEventGetMouseX();
                    y1=tumEventGetMouseY();

                    
                    vDrawGameover();
                    bestscore (  game.score );
                    Tryagain();
                 
                
                      
                } 
                 if (xSemaphoreTake(buttons.lock, 0) == pdTRUE) {
                        if (tumEventGetMouseLeft()&& x1 > x_min && x1 < x_max && y1 > y_min && y1 < y_max) {
                       game.score =0; 
                        game.gameover=0;
                        initwalls();
                    }

                    xSemaphoreGive(buttons.lock);    

                    }
                    
                      
                   
                if ( game.gameover==0 ){
                    uStatesSetState(STATE_TWO); 
                }     
              
        }
    }
}




void vPlayBallSound(void *args)
{
    tumSoundPlaySample(a3);
}



void vStateTwoEnter(void)
{

    vTaskResume(DemoTask2);
}

void vStateTwoExit(void)
{
    vTaskSuspend(DemoTask2);
}
// Playing task
void vDemoTask2(void *pvParameters)
{ 
    TickType_t xLastFrameTime = xTaskGetTickCount();
    TickType_t delay = xLastFrameTime;
    TickType_t animation = xLastFrameTime;
    int STARTING_POS = (BirdSpace)/2;
    int y = STARTING_POS;
    float velo = 0;
    int x_min=550;
    int x_max=611;
    int y_min=10;
    int y_max=71; 
    int  x1;
    int  y1;
    game.count_down = 3;
    while (1) {
        if (DrawSignal)
            if (xSemaphoreTake(DrawSignal, portMAX_DELAY) ==
                pdTRUE) {
            x1=tumEventGetMouseX();
            y1=tumEventGetMouseY();    
            if ( game.gameover == 0) {
                vDrawClearScreen();
                vDrawStaticItems();
                vGetButtonInput();
                Stop();

                if ( game.count_down< 0) {
                    vDrawOBS(xLastFrameTime, y, &game.gameover, &game.score );
                    vDrawScoreDU(&delay, &game.score );
        
                }
                else {
                    vDrawCountDown(&delay, &game.count_down ); 
                }

                vDrawDaBird(y, &velo, &animation);
                        // vDrawDaBird(y + 100, &velo);
                if (y + velo <= 0) {
                    y = 0;
                    velo = 0.0;
                } 

            
                
                //add gravity if he is not touching ground 
                if (y + 24 + velo <= BirdSpace &&  game.count_down<= 0) {
                    velo += GRAVITY;  

                }
                else {
                    velo = 0;

                }
                y += (int) velo;
           



            if (xSemaphoreTake(buttons.lock, 0) == pdTRUE) {
                if (tumEventGetMouseLeft()) {
                    if (x1 > x_min && x1 < x_max && y1 > y_min && y1 < y_max)                           
                                uStatesSetState(STATE_FOUR);
                                
                        }    
                        xSemaphoreGive(buttons.lock);
                    }
            }      

            if ( game.gameover == 1) {
                y = STARTING_POS;
                 game.count_down= 3;
                uStatesSetState(STATE_THREE);
            }
            xLastFrameTime = xTaskGetTickCount();
            
        }
    }
}
void vStateFourEnter(void)
{

    vTaskResume(DemoTask4);
}

void vStateFourExit(void)
{
    vTaskSuspend(DemoTask4);
}
// Resume task
void vDemoTask4(void *pvParameters)
{ 
    int x_min=280;
    int x_max=350;
    int y_min=270;
    int y_max=310; 
    int  x1;
    int  y1;
 
    while (1) {
        if (DrawSignal)
            if (xSemaphoreTake(DrawSignal, portMAX_DELAY) ==
                    pdTRUE) {
                        
            tumEventFetchEvents(FETCH_EVENT_BLOCK |
                                            FETCH_EVENT_NO_GL_CHECK);
            vGetButtonInput();
            Paused();
            Tryagain();
            x1=tumEventGetMouseX();
            y1=tumEventGetMouseY();

            if (xSemaphoreTake(buttons.lock, 0) == pdTRUE) {
                if (tumEventGetMouseLeft()) {
                    if (x1 > x_min && x1 < x_max && y1 > y_min && y1 < y_max)                          
                        uStatesSetState(STATE_TWO);                    
                }   
                            
            xSemaphoreGive(buttons.lock);
            }
        }

    }
}





void vDemoSendTask(void *pvParameters)
{
    static char *test_str_1 = "UDP test 1";
    static char *test_str_2 = "UDP test 2";
    static char *test_str_3 = "TCP test";

    while (1) {
        prints("*****TICK******\n");
        if (mq_one) {
            aIOMessageQueuePut(mq_one_name, "Hello MQ one");
        }
        if (mq_two) {
            aIOMessageQueuePut(mq_two_name, "Hello MQ two");
        }

        if (udp_soc_one)
            aIOSocketPut(UDP, NULL, UDP_TEST_PORT_1, test_str_1,
                         strlen(test_str_1));
        if (udp_soc_two)
            aIOSocketPut(UDP, NULL, UDP_TEST_PORT_2, test_str_2,
                         strlen(test_str_2));
        if (tcp_soc)
            aIOSocketPut(TCP, NULL, TCP_TEST_PORT, test_str_3,
                         strlen(test_str_3));

        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

int xCreateDemoTasks(void)
{
    if (xTaskCreate(vDemoTask1, "DemoTask1", mainGENERIC_STACK_SIZE * 2,
                    NULL, mainGENERIC_PRIORITY + 1, &DemoTask1) != pdPASS) {
        PRINT_TASK_ERROR("DemoTask1");
        goto err_task1;
    }
    if (xTaskCreate(vDemoTask2, "DemoTask2", mainGENERIC_STACK_SIZE * 2,
                    NULL, mainGENERIC_PRIORITY + 1, &DemoTask2) != pdPASS) {
        PRINT_TASK_ERROR("DemoTask2");
        goto err_task2;
    }
    if (xTaskCreate(vDemoTask3, "DemoTask3", mainGENERIC_STACK_SIZE * 2,
			NULL, mainGENERIC_PRIORITY + 1, &DemoTask3) != pdPASS) {
		PRINT_TASK_ERROR("DemoTask3");
		goto err_task3;
	}
    if (xTaskCreate(vDemoTask4, "DemoTask4", mainGENERIC_STACK_SIZE * 2,
			NULL, mainGENERIC_PRIORITY + 1, &DemoTask4) != pdPASS) {
		PRINT_TASK_ERROR("DemoTask3");
		goto err_task4;
	}

    if (xTaskCreate(vDemoSendTask, "DemoSendTask",
                    mainGENERIC_STACK_SIZE * 2, NULL,
                    configMAX_PRIORITIES - 1, &DemoSendTask) != pdPASS) {
        PRINT_TASK_ERROR("DemoSendTask");
        goto err_send_task;
    }

    vTaskSuspend(DemoTask1);
    vTaskSuspend(DemoTask2);
    vTaskSuspend(DemoTask3);
     vTaskSuspend(DemoTask4);
    return 0;

err_send_task:
    vTaskDelete(DemoTask4);
err_task4:
    vTaskDelete(DemoTask3);
err_task3:
    vTaskDelete(DemoTask2);
    err_task2:
    vTaskDelete(DemoTask1);
err_task1:
    return -1;
}

void vDeleteDemoTasks(void)
{
    if (DemoTask1) {
        vTaskDelete(DemoTask1);
    }
    if (DemoTask2) {
        vTaskDelete(DemoTask2);
    }
    if (DemoTask3) {
		vTaskDelete(DemoTask3);
	}
    if (DemoTask4) {
		vTaskDelete(DemoTask4);
	}
    if (DemoSendTask) {
        vTaskDelete(DemoSendTask);
    }
}
