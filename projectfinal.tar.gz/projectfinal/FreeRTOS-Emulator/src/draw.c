#include <stdio.h>

#include "TUM_Font.h"
#include "TUM_Event.h"
#include "TUM_Utils.h"
#include "TUM_Print.h"
#include "TUM_Sound.h"
#include "defines.h"
#include "buttons.h"
#include "draw.h"
#include <time.h>
#include <stdlib.h>
#include <stdbool.h>

#define FPS_AVERAGE_COUNT 50
#define LOGO_FILENAME "freertos.jpg"

#define CAVE_SIZE_X SCREEN_WIDTH / 2
#define CAVE_SIZE_Y SCREEN_HEIGHT / 2
#define CAVE_X CAVE_SIZE_X / 2
#define CAVE_Y CAVE_SIZE_Y / 2
#define CAVE_THICKNESS 25
#define BirdSpace 368

#define DEF_MEDIUM 10
#define DEF_HARD 20
#define DEF_SON_OF_SPARTA 50

image_handle_t logo_image = NULL;
image_handle_t background = NULL;
image_handle_t bird[] = {NULL,NULL,NULL};
image_handle_t pipe = NULL; 
image_handle_t pipe1 = NULL; 
image_handle_t g_gameover = NULL;
image_handle_t GROUND = NULL;
image_handle_t number = NULL;
image_handle_t start = NULL;
image_handle_t highscore = NULL;
image_handle_t Menu= NULL;
image_handle_t replay = NULL;
image_handle_t win= NULL;
image_handle_t gold= NULL;
image_handle_t bronze= NULL;
image_handle_t silver= NULL;
image_handle_t paused= NULL;
image_handle_t p= NULL;
image_handle_t plat= NULL;
image_handle_t R= NULL;


bool g_Cheat = false;




#define SCORE 1

int WALLS_X[10] = {-100,};
int WALLS_Y[] = {-10,20,30,-50,10,50,-20,30,-10,30};

void vCheckDraw(unsigned char status, const char *msg)
{
    if (status) {
        if (msg)
            fprints(stderr, "[ERROR] %s, %s\n", msg,
                    tumGetErrorMessage());
        else {
            fprints(stderr, "[ERROR] %s\n", tumGetErrorMessage());
        }
    }
}

void vDrawClearScreen(void)
{
    vCheckDraw(tumDrawClear(White), __FUNCTION__);
}











void vDrawLogo(void)
{
    static int image_height;

    if (logo_image == NULL) {
        logo_image = tumDrawLoadImage(LOGO_FILENAME);
    }

    if ((image_height = tumDrawGetLoadedImageHeight(logo_image)) != -1)
        vCheckDraw(tumDrawLoadedImage(logo_image, 10,
                                      SCREEN_HEIGHT - 10 - image_height),
                   __FUNCTION__);
    else {
        fprints(stderr,
                "Failed to get size of image '%s', does it exist?\n",
                LOGO_FILENAME);
    }
}
void vDrawBackground(void) {
    static int image_width;

    if (background == NULL) {
        background = tumDrawLoadImage("background-day.png");
        
    }

    if ((image_width = tumDrawGetLoadedImageHeight(background)) != -1) {
        vCheckDraw(tumDrawLoadedImage(background, 0, 0),
                   __FUNCTION__);
        vCheckDraw(tumDrawLoadedImage(background, 128, 0),
                   __FUNCTION__);
        vCheckDraw(tumDrawLoadedImage(background, 256, 0),
                   __FUNCTION__);
        vCheckDraw(tumDrawLoadedImage(background, 512, 0),
                   __FUNCTION__);  
     
    }
    else {
        fprints(stderr,
                "Failed to get size of image '%s', does it exist?\n",
                LOGO_FILENAME);
    }
    

}
void vDrawStaticItems(void)
{
    
    vDrawBackground();
    
    
}

void vDrawGameover(void)
{
    static int image_height;

    if (g_gameover == NULL) {
        g_gameover = tumDrawLoadImage("gameover.png");
    }

    if ((image_height = tumDrawGetLoadedImageHeight(g_gameover)) != -1)
        vCheckDraw(tumDrawLoadedImage(g_gameover, SCREEN_WIDTH/2-100,
                                      SCREEN_HEIGHT/2),
                   __FUNCTION__);
    else {
        fprints(stderr,
                "Failed to get size of image '%s', does it exist?\n",
                LOGO_FILENAME);
    }
}

double map(double x, double in_min, double in_max, double out_min, double out_max) {
    if (x > in_max)
        return out_max;
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

void vDrawOBS(TickType_t tick, int y, int* gameover, int* score) {

    if (pipe == NULL) {
        pipe = tumDrawLoadScaledImage("pipe-red.png", 1.0);
        
    }
     if (pipe1 == NULL) {
        pipe1 = tumDrawLoadScaledImage("pipe-red1.png", 1.0);
        
    }
    
    int image_height = tumDrawGetLoadedImageHeight(pipe);
    int image_width = tumDrawGetLoadedImageWidth(pipe);

    int GAPY = 200;
    int GAPX = 250;

    if (*score >= DEF_MEDIUM)
        GAPY -= map(*score, DEF_MEDIUM, DEF_HARD, 0, 60); // decreasing  vertical gap depending on difficulty
    
    if (*score >= DEF_HARD)
        GAPX -=  map(*score, DEF_HARD, DEF_SON_OF_SPARTA, 0, 50);// decreasing  horizental gap depending on difficulty
    
    int WALL_SPEED = 5 + (int)map(*score, 0, DEF_SON_OF_SPARTA, 0, 2); //increasing game speed depending on  difficulty


    int n = 10; // number of walls;
    
    //init walls
    if (WALLS_X[0] == -100) {
        for (int i = 0; i < n; i++) {
                WALLS_X[i] = SCREEN_WIDTH + image_width + GAPX*i;
        }
    }

    for (int i = 0; i < n; i++) {
        if (WALLS_X[i] <= SCREEN_WIDTH) {
        vCheckDraw(tumDrawLoadedImage(pipe1, WALLS_X[i],  -image_height+(BirdSpace
)/2-GAPY/2+WALLS_Y[i]),
                   __FUNCTION__);


        vCheckDraw(tumDrawLoadedImage(pipe, WALLS_X[i],  (BirdSpace
)/2+GAPY/2+WALLS_Y[i]),
                   __FUNCTION__);
        
        }

        WALLS_X[i] -= WALL_SPEED;
    }
    //floor animation
    for (int i = 0; i < 6; i++) {
        vCheckDraw(tumDrawLoadedImage(GROUND, WALLS_X[0]+672-336*i, BirdSpace
),
                   __FUNCTION__);  
    }
    // floor col
    if (y+24 >= BirdSpace) {
            *gameover = g_Cheat ? 0 : 1;  
            if (g_Cheat == 0 ) tumSoundPlaySample(a4);
    }

    // pipes col 
    if (WALLS_X[0] < 24) {     
        if (!((BirdSpace)/2+GAPY/2+WALLS_Y[0] > (y+24) && (BirdSpace
)/2-GAPY/2+WALLS_Y[0] < (y))){
            *gameover= g_Cheat ? 0 : 1;
            if (g_Cheat == 0 ) 
                tumSoundPlaySample(a4);
            }

    }
   
    

    //shifting walls
    if (WALLS_X[0] < -image_width) {
            int aux = WALLS_X[n - 1]; 

            int j;
            for (j = 0; j < n - 1; j++) {
                WALLS_X[j] = WALLS_X[j + 1];
                WALLS_Y[*score > DEF_SON_OF_SPARTA ? 0 : j] = WALLS_Y[j + 1];
            } 

            WALLS_X[j] = aux + GAPX;
            WALLS_Y[j] = (int) (sin(cos(cos(tick*100)*100)*100)*70);
            *score += SCORE;
    }

    

}



void vDrawCountDown(TickType_t* tick, int* sec) {
    if (*sec < 0) return;
    int DELAY = 500;
    char buffer[32];
    TickType_t lastframe = xTaskGetTickCount();

    sprintf(buffer, "%d.png", *sec);

    if (number == NULL)
        number = tumDrawLoadScaledImage(buffer, 1);

    if (lastframe - *tick >= DELAY) {
        *tick = lastframe;
        *sec -= 1;
        number = tumDrawLoadScaledImage(buffer, 1);
    }

    vCheckDraw(tumDrawLoadedImage(number, SCREEN_WIDTH/2, SCREEN_HEIGHT/2 - 100),
                   __FUNCTION__);
    if (GROUND == NULL)
        GROUND = tumDrawLoadImage("base.png");
    for (int i = 0; i < 6; i++) {
        vCheckDraw(tumDrawLoadedImage(GROUND, WALLS_X[0]+672-336*i, BirdSpace),
                   __FUNCTION__);  
    }
}
void vDrawScoreDU(TickType_t* tick, int* score) {

    font_handle_t cur_font = tumFontGetCurFontHandle();
    tumFontSelectFontFromName(FLAPPY_FONT);
    

    static char str[254] = { 0 };

    char defficulty[32];
    if (*score >= DEF_SON_OF_SPARTA)
        sprintf(defficulty, "SON OF SPARTA");
    else if (*score >= DEF_HARD)
        sprintf(defficulty, "HARD");
    else if (*score >= DEF_MEDIUM)
        sprintf(defficulty, "MEDIUM");
    else 
        sprintf(defficulty, "EASY");
    
    tumFontSetSize(50);

    sprintf(str, "SCORE %d   %s", *score, g_Cheat ? "Cheat ON" : "");
    
    vCheckDraw(tumDrawText(str, 0, SCREEN_HEIGHT - 100 , White),
                   __FUNCTION__);

    sprintf(str, "Defficulty %s", defficulty);
    
    vCheckDraw(tumDrawText(str, 0, SCREEN_HEIGHT - 50 , White),
                   __FUNCTION__);

    tumFontSetSize(DEFAULT_FONT_SIZE);

    tumFontSelectFontFromHandle(cur_font);
    tumFontPutFontHandle(cur_font);   

}
// initialisation of the pipes pos
void initwalls(void){
WALLS_X[0] = -100;
WALLS_Y[0] = -10;
WALLS_Y[1] = 20;
WALLS_Y[2] = 30;
WALLS_Y[3] = -50;
WALLS_Y[4] = 10;
WALLS_Y[5] = 50;
WALLS_Y[6] = -20;
WALLS_Y[7] = 30;
WALLS_Y[8] = -10;
WALLS_Y[9] = 30;

}
// drawing the bird in the game and make it move
void vDrawDaBird(int y, float* velo, TickType_t *tick) {
    static int image_width;
    bool g_ButtonReleased = true;
    bool g_SButtonReleased = true;
    int g_iFrame_number = 0;
    if (xTaskGetTickCount() - *tick > 100) {
        g_iFrame_number += 1;
        *tick = xTaskGetTickCount();
    }
    

    char buffer[64];
    char buffer0[32];
    sprintf(buffer0, "yellowbird");
    if (g_Cheat) 
        sprintf(buffer0, "redbird");
    if (g_iFrame_number > 2)
        g_iFrame_number = 0;
    
    if (bird[0] == NULL) {
        sprintf(buffer, "%s-downflap.png", buffer0);
        bird[0] = tumDrawLoadImage(buffer);
        sprintf(buffer, "%s-midflap.png", buffer0);
        bird[1] = tumDrawLoadImage(buffer);
        sprintf(buffer, "%s-upflap.png", buffer0);
        bird[2] = tumDrawLoadImage(buffer);
    }
    

    if ((image_width = tumDrawGetLoadedImageHeight(bird[g_iFrame_number])) != -1) {
        vCheckDraw(tumDrawLoadedImage(bird[g_iFrame_number], 0, y),
                   __FUNCTION__);
    }
    else {
        fprints(stderr,
                "Failed to get size of image '%s', does it exist?\n",
                LOGO_FILENAME);
    }

    if (xSemaphoreTake(buttons.lock, 0) == pdTRUE) {
        if (buttons.buttons[KEYCODE(W)])  {
            if (g_ButtonReleased) {
                *velo = -5;
                tumSoundPlaySample(a3);
                g_ButtonReleased = false;
            }
        } else g_ButtonReleased = true;
        if (buttons.buttons[KEYCODE(S)]) {
            if (g_SButtonReleased) {
                g_Cheat = g_Cheat ? false : true;
                bird[0] = NULL;
                g_SButtonReleased = false;
            }
        } else g_SButtonReleased = true;
        xSemaphoreGive(buttons.lock);

    }
    
}

void vDrawMenu(int x) {
    static int image_width;
     

 vDrawBackground();
    if (Menu== NULL) {
        Menu= tumDrawLoadImage("FlappyBird.png");
        
    }

    if ((image_width = tumDrawGetLoadedImageHeight(Menu)) != -1) {
      
        vCheckDraw(tumDrawLoadedImage(Menu, 180, x),
                   __FUNCTION__);
       
     
    }
    else {
        fprints(stderr,
                "Failed to get size of image '%s', does it exist?\n",
                LOGO_FILENAME);
    }
     if (start== NULL) {
        start= tumDrawLoadImage("playbtn.png");
        
    }

    if ((image_width = tumDrawGetLoadedImageHeight(start)) != -1) {
      
        vCheckDraw(tumDrawLoadedImage(start, 104, 280),
                   __FUNCTION__);
       
     
    }
    else {
        fprints(stderr,
                "Failed to get size of image '%s', does it exist?\n",
                LOGO_FILENAME);
    }
if (highscore== NULL) {
        highscore= tumDrawLoadImage("high score.png");
        
    }

    if ((image_width = tumDrawGetLoadedImageHeight(highscore)) != -1) {
      
        vCheckDraw(tumDrawLoadedImage(highscore, 378, 280),
                   __FUNCTION__);
       
     
    }
    else {
        fprints(stderr,
                "Failed to get size of image '%s', does it exist?\n",
                LOGO_FILENAME);
    }
     
}

void vDrawInterface(int* GameType) {

    static char str[32] = { 0 };

    
    tumFontSetSize(50);

    sprintf(str, "Bonjour %d", *GameType);
    
    vCheckDraw(tumDrawText(str, 0, SCREEN_HEIGHT - 100 , White),
                   __FUNCTION__);


    tumFontSetSize(DEFAULT_FONT_SIZE);

}

void vDrawButtonText(void)
{
    static char str[100] = { 0 };

    sprintf(str, "Axis 1: %5d | Axis 2: %5d", tumEventGetMouseX(),
            tumEventGetMouseY());

    vCheckDraw(tumDrawText(str, 10, DEFAULT_FONT_SIZE * 0.5, Black),
               __FUNCTION__);

    if (xSemaphoreTake(buttons.lock, 0) == pdTRUE) {
        sprintf(str, "W: %d | S: %d | A: %d | D: %d",
                buttons.buttons[KEYCODE(W)],
                buttons.buttons[KEYCODE(S)],
                buttons.buttons[KEYCODE(A)],
                buttons.buttons[KEYCODE(D)]);
        xSemaphoreGive(buttons.lock);
        vCheckDraw(tumDrawText(str, 10, DEFAULT_FONT_SIZE * 2, Black),
                   __FUNCTION__);
    }

    if (xSemaphoreTake(buttons.lock, 0) == pdTRUE) {
        sprintf(str, "UP: %d | DOWN: %d | LEFT: %d | RIGHT: %d",
                buttons.buttons[KEYCODE(UP)],
                buttons.buttons[KEYCODE(DOWN)],
                buttons.buttons[KEYCODE(LEFT)],
                buttons.buttons[KEYCODE(RIGHT)]);
        xSemaphoreGive(buttons.lock);
        vCheckDraw(tumDrawText(str, 10, DEFAULT_FONT_SIZE * 3.5, Black),
                   __FUNCTION__);
    }
}


void Tryagain(void) {
   static int image_width;
   if (replay== NULL) {
        replay= tumDrawLoadImage("try again.png");
        
    }

    if ((image_width = tumDrawGetLoadedImageHeight(replay)) != -1) {
      
        vCheckDraw(tumDrawLoadedImage(replay, 284, 284),
                   __FUNCTION__);
       
     
    }
    else {
        fprints(stderr,
                "Failed to get size of image '%s', does it exist?\n",
                LOGO_FILENAME);
    }
}




void Paused(void){
     static int image_width;
   if (paused== NULL) {
        paused= tumDrawLoadImage("paused.png");
        
    }

    if ((image_width = tumDrawGetLoadedImageHeight(paused)) != -1) {
      
        vCheckDraw(tumDrawLoadedImage(paused, 225, 120),
                   __FUNCTION__);
       
     
    }
    else {
        fprints(stderr,
                "Failed to get size of image '%s', does it exist?\n",
                LOGO_FILENAME);
    }
}
    



void Stop(void){
     static int image_width;
   if (p== NULL) {
        p= tumDrawLoadImage("Pause.png");
        
    }

    if ((image_width = tumDrawGetLoadedImageHeight(p)) != -1) {
      
        vCheckDraw(tumDrawLoadedImage(p, 550, 10),
                   __FUNCTION__);
       
     
    }
    else {
        fprints(stderr,
                "Failed to get size of image '%s', does it exist?\n",
                LOGO_FILENAME);
    }
}
     
    
  
void bestscore(int score)
{
   static int image_width;
    static char str[254] = { 0 };
    static char ch[254] = { 0 };
    int g_iHighscore = 0;
    font_handle_t cur_font = tumFontGetCurFontHandle();
    tumFontSelectFontFromName(FLAPPY_FONT);  


    if (score > g_iHighscore) {
        g_iHighscore = score;
    }

    
    if (win== NULL) {
        win= tumDrawLoadImage("win.png");
        
    }

    if ((image_width = tumDrawGetLoadedImageHeight(win)) != -1) {
      
        vCheckDraw(tumDrawLoadedImage(win, 222, 153),
                   __FUNCTION__);
       
     
    }
    else {
        fprints(stderr,
                "Failed to get size of image '%s', does it exist?\n",
                LOGO_FILENAME);

}

// coin bronze
if (score>9&& score<20){
 if (bronze== NULL) {
        bronze= tumDrawLoadImage("bronzeCoin.png");
        
    }

    if ((image_width = tumDrawGetLoadedImageHeight(bronze)) != -1) {
      
        vCheckDraw(tumDrawLoadedImage(bronze, 242, 185),
                   __FUNCTION__);
       
     
    }
    else {
        fprints(stderr,
                "Failed to get size of image '%s', does it exist?\n",
                LOGO_FILENAME);

}
}


// silver coin
if (score>19&& score <30){
if (silver== NULL) {
        silver= tumDrawLoadImage("silverCoin.png");
        
    }

    if ((image_width = tumDrawGetLoadedImageHeight(silver)) != -1) {
      
        vCheckDraw(tumDrawLoadedImage(silver, 242, 185),
                   __FUNCTION__);
       
     
    }
    else {
        fprints(stderr,
                "Failed to get size of image '%s', does it exist?\n",
                LOGO_FILENAME);

}
}
//gold coin
if (score>29&&score<40){
if (gold== NULL) {
        gold= tumDrawLoadImage("goldCoin.png");
        
    }

    if ((image_width = tumDrawGetLoadedImageHeight(gold)) != -1) {
      
        vCheckDraw(tumDrawLoadedImage(gold, 242, 185),
                   __FUNCTION__);
       
     
    }
    else {
        fprints(stderr,
                "Failed to get size of image '%s', does it exist?\n",
                LOGO_FILENAME);

}
}
if (score>39){

if (plat== NULL) {
        plat= tumDrawLoadImage("plati.png");
        
    }

    if ((image_width = tumDrawGetLoadedImageHeight(plat)) != -1) {
      
        vCheckDraw(tumDrawLoadedImage(plat, 242, 185),
                   __FUNCTION__);
       
     
    }
    else {
        fprints(stderr,
                "Failed to get size of image '%s', does it exist?\n",
                LOGO_FILENAME);

}
}

tumFontSetSize(30);

    sprintf(str, " %d", score);
    vCheckDraw(tumDrawText(str, 346,178, Black), __FUNCTION__);
    sprintf(ch, " %d", g_iHighscore );
    vCheckDraw(tumDrawText(ch, 346,200, Black), __FUNCTION__);
    tumFontSelectFontFromHandle(cur_font);
    tumFontPutFontHandle(cur_font);
}
void vReturn(void)
{
static int image_width;
if (R== NULL) {
 R= tumDrawLoadImage("return.png");
        
    }

    if ((image_width = tumDrawGetLoadedImageHeight(R)) != -1) {
      
        vCheckDraw(tumDrawLoadedImage(R, 537, 11),
                   __FUNCTION__);
       
     
    }
    else {
        fprints(stderr,
                "Failed to get size of image '%s', does it exist?\n",
                LOGO_FILENAME);


}
}