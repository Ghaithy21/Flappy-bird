#ifndef __MAIN_H__
#define __MAIN_H__

#include "FreeRTOS.h"
#include "semphr.h"

#include "state_machine.h"

extern SemaphoreHandle_t DrawSignal;

#endif //__MAIN_H__