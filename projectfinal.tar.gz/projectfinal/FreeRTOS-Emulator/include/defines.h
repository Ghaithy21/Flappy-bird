#ifndef __DEFINES_H__
#define __DEFINES_H__

#define mainGENERIC_PRIORITY (tskIDLE_PRIORITY)
#define mainGENERIC_STACK_SIZE ((unsigned short)2560)

#define FPS_FONT "IBMPlexSans-Bold.ttf"
#define FLAPPY_FONT "Flappybird.ttf"


#endif // __DEFINES_H__