---
name: Discussion
about: Starting a friendly discussion about something relating to this repository
title: "[DISCUSSION]"
labels: Discussion
assignees: ''

---
